package com.nostalgiaguy.springsecuritybasic.config;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authorization.AuthenticatedAuthorizationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

@Configuration
public class ProjectSecurityConfig extends WebSecurityConfigurerAdapter {
	
	private final Log logger = LogFactory.getLog(ProjectSecurityConfig.class);

	/* protected void configure(HttpSecurity http) throws Exception {
		this.logger.debug("Using default configure(HttpSecurity). "
				+ "If subclassed this will potentially override subclass configure(HttpSecurity)."+"  ooo guddu pandit");
		http.authorizeRequests((requests) -> requests.anyRequest().authenticated());
		http.formLogin();
		http.httpBasic();
		
	}
	*/
	
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests()
			.antMatchers("/contact").permitAll()
			.antMatchers("/notices").permitAll()
			.antMatchers("/welcome").permitAll()
			.antMatchers("/console/**").permitAll()
			.antMatchers("/myLoans").authenticated()
			.antMatchers("/myAccount").authenticated()
			.antMatchers("/myBalance").authenticated()
			.antMatchers("/myCards").authenticated()
			.and().formLogin()
			.and().httpBasic();	
		
		
		http.csrf().disable();
        http.headers().frameOptions().disable();
	}
	
	/*protected void configure(AuthenticationManagerBuilder auth) throws Exception {		
		auth.inMemoryAuthentication().withUser("admin").password("54321").authorities("admin")
			.and().withUser("user").password("12345").authorities("read")
			.and().passwordEncoder(NoOpPasswordEncoder.getInstance());	
	}*/
	
	/*protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		InMemoryUserDetailsManager userDetailsManager = new InMemoryUserDetailsManager();
		UserDetails u1 = User.withUsername("admin").password("54321").authorities("admin").build();
		UserDetails u2 = User.withUsername("User").password("12345").authorities("admin").build();
		userDetailsManager.createUser(u1);
		userDetailsManager.createUser(u2);
		auth.userDetailsService(userDetailsManager);
		
	}*/
	
	@Bean
	public PasswordEncoder defaultPasswordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	
	// denyAll() -- deny all request , error 403 forbidden error
	// permitAll()  -- permit all request
	// Authentication failure  -  error 401 unauthorized error
	
	/*
	   * /contact
	   * /myLoans
	   * /notices
	   * /welcome
	   * /myAccount
	   * /myBalance
	   * /myCards
	*/

}

package com.nostalgiaguy.springsecuritybasic.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ContactController {
	
	@GetMapping("/contact")
	public String saveContactInquiryDetails(String inpurt) {
		return "Inquiry details are saved to the DB";
	}

}

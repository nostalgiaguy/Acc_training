



INSERT INTO `customer` 
 VALUES (1001,'johndoe@example.com', '$2a$12$BHCP2MQjB5sK0j8QBmw41erprIhf6hniDPBwSyW9bauoUqvUDciSe', 'admin');
 
 INSERT INTO `customer` 
 VALUES (1002,'guddu@example.com', '1234', 'admin');
 
 
 INSERT INTO `customer` 
 VALUES (1003,'pandit@example.com', '4321', 'admin');
 
 
 INSERT INTO `customer` 
 VALUES (1004,'romy@example.com', '55555', 'admin');